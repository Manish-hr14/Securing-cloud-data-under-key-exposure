package com.TMACS.conn;

public class listoffiles {
	String id;
	String email;
	String fileName;
	String file_key;
	public void setId(String id) {
		this.id = id;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public void setFile_key(String file_key) {
		this.file_key = file_key;
	}
	public String getId() {
		return id;
	}
	public String getEmail() {
		return email;
	}
	public String getFileName() {
		return fileName;
	}
	public String getFile_key() {
		return file_key;
	}
}
