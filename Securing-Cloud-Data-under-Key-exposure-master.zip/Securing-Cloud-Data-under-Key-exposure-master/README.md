# Securing-Cloud-Data-under-Key-exposure
A Bastion concept, a scheme which ensures the confidentiality of encrypted data even when the adversary has the encryption key has been implemented.
